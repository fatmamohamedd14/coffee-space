# Coffee Space

Café operations platform — POS, inventory, purchasing, floor tables, reports, roles, multi-branch.

## Run locally

```bash
node server.js
```

Open: http://localhost:3000

## Demo accounts

| Role    | Username | Password       |
|---------|----------|----------------|
| Manager | manager  | Manager@2026   |
| Cashier | cashier  | Cashier@2026   |

## Deploy

Works on any host that runs Node:

- Railway / Render / Fly.io: set start command `node server.js`
- Or serve the `public/` folder as static files (Netlify, Vercel, nginx)

Data is stored in the browser (localStorage) in this version.

## Structure

```
coffee-space/
  package.json
  server.js
  README.md
  public/
    index.html
    css/style.css
    js/app.js
```
