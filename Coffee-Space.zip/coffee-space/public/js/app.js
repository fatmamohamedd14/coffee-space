/* =========================================================
   STATE + PERSISTENCE
   ========================================================= */
const STORAGE_KEY = 'coffeeSpaceState_v1';

function mulberry32(seed){
  return function(){
    seed |= 0; seed = seed + 0x6D2B79F5 | 0;
    let t = Math.imul(seed ^ seed >>> 15, 1 | seed);
    t = t + Math.imul(t ^ t >>> 7, 61 | t) ^ t;
    return ((t ^ t >>> 14) >>> 0) / 4294967296;
  };
}

function defaultState(){
  const products = {
    turkish_single:{id:'turkish_single',name:'قهوة تركي سنجل',nameEn:'Turkish Coffee Single',categoryId:'drinks',kind:'prepared',price:35,active:true,recipe:{beans:12,sugar:6,cups:1}},
    turkish_double:{id:'turkish_double',name:'قهوة تركي دبل',nameEn:'Turkish Coffee Double',categoryId:'drinks',kind:'prepared',price:50,active:true,recipe:{beans:20,sugar:8,cups:1}},
    french:{id:'french',name:'قهوة فرنسي',nameEn:'French Coffee',categoryId:'drinks',kind:'prepared',price:55,active:true,recipe:{beans:14,milk:80,cups:1}},
    espresso_double:{id:'espresso_double',name:'إسبريسو دبل',nameEn:'Double Espresso',categoryId:'drinks',kind:'prepared',price:60,active:true,recipe:{beans:18,cups:1}},
    americano:{id:'americano',name:'أمريكانو',nameEn:'Americano',categoryId:'drinks',kind:'prepared',price:70,active:true,recipe:{beans:18,cups:1}},
    macchiato:{id:'macchiato',name:'ماكياتو',nameEn:'Macchiato',categoryId:'drinks',kind:'prepared',price:70,active:true,recipe:{beans:18,milk:25,cups:1}},
    cortado:{id:'cortado',name:'كورتادو',nameEn:'Cortado',categoryId:'drinks',kind:'prepared',price:75,active:true,recipe:{beans:18,milk:70,cups:1}},
    flatwhite:{id:'flatwhite',name:'فلات وايت',nameEn:'Flat White',categoryId:'drinks',kind:'prepared',price:95,active:true,recipe:{beans:18,milk:130,cups:1}},
    latte:{id:'latte',name:'لاتيه',nameEn:'Latte',categoryId:'drinks',kind:'prepared',price:105,active:true,recipe:{beans:18,milk:200,cups:1}},
    cappuccino:{id:'cappuccino',name:'كابتشينو',nameEn:'Cappuccino',categoryId:'drinks',kind:'prepared',price:130,active:true,recipe:{beans:18,milk:150,cups:1}},
    spanish:{id:'spanish',name:'سبانيش لاتيه',nameEn:'Spanish Latte',categoryId:'drinks',kind:'prepared',price:125,active:true,recipe:{beans:18,milk:170,condensed:35,cups:1}},
    mocha:{id:'mocha',name:'موكا لاتيه',nameEn:'Mocha Latte',categoryId:'drinks',kind:'prepared',price:125,active:true,recipe:{beans:18,milk:170,chocolate:25,cups:1}},
    croissant:{id:'croissant',name:'كرواسون سادة',nameEn:'Plain Croissant',categoryId:'desserts',kind:'prepared',price:100,active:true,recipe:{croissantUnit:1}},
    brownie:{id:'brownie',name:'شوكليت براوني',nameEn:'Chocolate Brownie',categoryId:'desserts',kind:'prepared',price:80,active:true,recipe:{brownieUnit:1}},
    applecake:{id:'applecake',name:'كيك تفاح بالقرفة',nameEn:'Apple Cinnamon Cake',categoryId:'desserts',kind:'prepared',price:120,active:true,recipe:{appleCakeSlice:1}},
    ab_plain_light_100:{id:'ab_plain_light_100',name:'عبد المعبود سادة فاتح - 100 جم',nameEn:'Coffee Space Plain Light Roast - 100g',categoryId:'beans',kind:'retail',price:105,cost:76,active:true,stock:{quantity:16,min:5}},
    ab_plain_medium_200:{id:'ab_plain_medium_200',name:'عبد المعبود سادة وسط - 200 جم',nameEn:'Coffee Space Plain Medium Roast - 200g',categoryId:'beans',kind:'retail',price:175,cost:128,active:true,stock:{quantity:14,min:4}},
    ab_plain_dark_200:{id:'ab_plain_dark_200',name:'عبد المعبود سادة غامق - 200 جم',nameEn:'Coffee Space Plain Dark Roast - 200g',categoryId:'beans',kind:'retail',price:175,cost:128,active:true,stock:{quantity:11,min:4}},
    ab_special_light_200:{id:'ab_special_light_200',name:'عبد المعبود محوج مخصوص فاتح - 200 جم',nameEn:'Coffee Space Special Cardamom Light - 200g',categoryId:'beans',kind:'retail',price:215,cost:158,active:true,stock:{quantity:12,min:4}},
    ab_special_medium_100:{id:'ab_special_medium_100',name:'عبد المعبود محوج مخصوص وسط - 100 جم',nameEn:'Coffee Space Special Cardamom Medium - 100g',categoryId:'beans',kind:'retail',price:125,cost:92,active:true,stock:{quantity:18,min:5}},
    ab_extra_dark_100:{id:'ab_extra_dark_100',name:'عبد المعبود محوج سوبر إكسترا غامق - 100 جم',nameEn:'Coffee Space Extra Cardamom Dark - 100g',categoryId:'beans',kind:'retail',price:150,cost:112,active:true,stock:{quantity:10,min:4}},
  };
  return {
    schemaVersion:8,
    categories:[
      {id:'drinks',name:'مشروبات القهوة',nameEn:'Coffee Drinks',icon:'ic-cup'},
      {id:'desserts',name:'مخبوزات وحلويات',nameEn:'Bakery & Desserts',icon:'ic-cake'},
      {id:'beans',name:'بن معبأ',nameEn:'Packaged Coffee',icon:'ic-bean'},
    ],
    rawMaterials:{
      beans:{name:'بن للتحضير',nameEn:'Coffee Beans for Preparation',unit:'جم',unitEn:'g',quantity:7000,min:1800,unitCost:0.72},
      milk:{name:'لبن كامل الدسم',nameEn:'Full-fat Milk',unit:'مل',unitEn:'ml',quantity:12000,min:3000,unitCost:0.06},
      sugar:{name:'سكر',nameEn:'Sugar',unit:'جم',unitEn:'g',quantity:4000,min:800,unitCost:0.04},
      condensed:{name:'لبن مكثف',nameEn:'Condensed Milk',unit:'مل',unitEn:'ml',quantity:2500,min:600,unitCost:0.12},
      chocolate:{name:'صوص شوكولاتة',nameEn:'Chocolate Sauce',unit:'مل',unitEn:'ml',quantity:2200,min:500,unitCost:0.16},
      cups:{name:'أكواب ورقية',nameEn:'Paper Cups',unit:'كوب',unitEn:'cup',quantity:180,min:50,unitCost:2.5},
      croissantUnit:{name:'كرواسون سادة',nameEn:'Plain Croissant',unit:'قطعة',unitEn:'pc',quantity:28,min:8,unitCost:62},
      brownieUnit:{name:'براوني جاهز',nameEn:'Chocolate Brownie',unit:'قطعة',unitEn:'pc',quantity:24,min:6,unitCost:48},
      appleCakeSlice:{name:'كيك تفاح بالقرفة',nameEn:'Apple Cinnamon Cake',unit:'شريحة',unitEn:'slice',quantity:18,min:5,unitCost:70},
    },
    products,
    suppliers:[
      {id:'sup1',name:'مورد البن والتعبئة',nameEn:'Coffee & Packaging Supplier',phone:'01000000001',notes:'توريد البن الخام ومستلزمات التعبئة'},
      {id:'sup2',name:'مورد الألبان اليومي',nameEn:'Daily Dairy Supplier',phone:'01000000002',notes:'توريد اللبن ومنتجات الألبان'},
    ],
    users:[
      {id:'u_manager',name:'أحمد حسن',nameEn:'Ahmed Hassan',username:'manager',password:'Manager@2026',role:'manager',active:true},
      {id:'u_cashier',name:'محمود علي',nameEn:'Mahmoud Ali',username:'cashier',password:'Cashier@2026',role:'cashier',active:true},
    ],
    branches:[
      {id:'tagamoa',name:'التجمع',nameEn:'Tagamoa'},
      {id:'babellouk',name:'باب اللوق',nameEn:'Bab El Louq'},
    ],
    purchases:[],expenses:[],waste:[],salesLog:[],customers:[],purchaseOrders:[],stockMovements:[],transfers:[],shifts:[],cashEntries:[],auditLog:[],tables:[
      {id:'t01',name:'T01',seats:2,area:'indoor',active:true},{id:'t02',name:'T02',seats:2,area:'indoor',active:true},{id:'t03',name:'T03',seats:4,area:'indoor',active:true},{id:'t04',name:'T04',seats:4,area:'indoor',active:true},{id:'t05',name:'T05',seats:6,area:'indoor',active:true},{id:'t06',name:'T06',seats:4,area:'outdoor',active:true}
    ]
  };
}

function computeProductCost(product){
  if(product.kind==='prepared'){
    let cost = 0;
    for(const [matId, amt] of Object.entries(product.recipe||{})){
      const mat = state.rawMaterials[matId];
      if(mat) cost += amt * (mat.unitCost||0);
    }
    return cost;
  }
  return product.cost || 0;
}

function generateHistoricalData(state){
  const rand = mulberry32(42);
  const productIds = Object.keys(state.products).filter(id=>state.products[id].active);
  const now = new Date();
  const todayStart = new Date(now.getFullYear(), now.getMonth(), now.getDate()).getTime();
  let orderId = 1;
  for(let daysAgo=29; daysAgo>=0; daysAgo--){
    const ordersToday = daysAgo===0 ? 7 : 5 + Math.floor(rand()*8);
    for(let o=0;o<ordersToday;o++){
      const itemCount = 1 + Math.floor(rand()*3);
      const items=[]; let total=0;
      for(let i=0;i<itemCount;i++){
        const pid=productIds[Math.floor(rand()*productIds.length)];
        const product=state.products[pid];
        const qty=1+Math.floor(rand()*2);
        const lineTotal=product.price*qty;
        items.push({productId:pid,name:product.name,nameEn:product.nameEn,categoryId:product.categoryId,qty,price:product.price,cost:computeProductCost(product),total:lineTotal});
        total+=lineTotal;
      }
      const hour=9+Math.floor(rand()*12), minute=Math.floor(rand()*60);
      const ts=todayStart-daysAgo*86400000+hour*3600000+minute*60000;
      const cashier=o%3===0?state.users[0]:state.users[1];
      const branch=o%4===0?'babellouk':'tagamoa';
      state.salesLog.push({id:orderId++,ts,items,total,orderType:o%3===0?'dinein':'takeaway',paymentMethod:o%4===0?'card':o%5===0?'wallet':'cash',userId:cashier.id,userName:cashier.name,userNameEn:cashier.nameEn,branch});
    }
  }
  state.salesLog.sort((a,b)=>a.ts-b.ts);
}


function loadState(){
  try{ const raw = localStorage.getItem(STORAGE_KEY); return raw ? JSON.parse(raw) : null; }
  catch(e){ return null; }
}
function saveState(){ try{ localStorage.setItem(STORAGE_KEY, JSON.stringify(state)); }catch(e){} }

let state = loadState();
if(!state){
  state = defaultState();
  saveState();
}
// State migration for older saved versions
state.expenses=state.expenses||[]; state.purchases=state.purchases||[]; state.waste=state.waste||[]; state.salesLog=state.salesLog||[]; state.customers=state.customers||[]; state.purchaseOrders=state.purchaseOrders||[]; state.stockMovements=state.stockMovements||[]; state.transfers=state.transfers||[]; state.shifts=state.shifts||[]; state.cashEntries=state.cashEntries||[]; state.auditLog=state.auditLog||[]; state.tables=state.tables||defaultState().tables; state.users=state.users||defaultState().users; state.branches=state.branches||defaultState().branches; state.schemaVersion=10; saveState();

let cart = {};
let currentReportPeriod = 'day';
let selectedAdminCategory = 'all';


/* =========================================================
   V8 SESSION + LANGUAGE + ACCESS
   ========================================================= */
let currentLang = localStorage.getItem('coffeeSpaceLang_v1') || 'ar';
let currentUser = null;
let currentBranch = sessionStorage.getItem('coffeeSpaceBranch_v1') || 'tagamoa';

const UI_TEXT = {
  'الرئيسية':'Dashboard','نقطة البيع':'Point of Sale','الصالة والترابيزات':'Floor & Tables','إضافة ترابيزة':'Add Table','عدد الكراسي':'Seats','إضافة ترابيزة':'Add Table','الترابيزة':'Table','اختاري الترابيزة':'Select table','إجمالي الترابيزات':'Total tables','متاحة للطلبات':'Available for orders','إجمالي الكراسي':'Total seats','كراسي':'seats','داخلي':'Indoor','خارجي':'Outdoor','نقطة البيع':'Point of Sale','المخزون والهالك':'Inventory & Waste','المشتريات والموردين':'Purchases & Suppliers','إدارة المنتجات':'Product Management','التقارير':'Reports','المستخدمون والصلاحيات':'Users & Access',
  'تسجيل الخروج':'Logout','ملخص التشغيل اليوم — المبيعات، الربحية، المخزون والتنبيهات في مكان واحد':'Today’s operations at a glance — sales, profitability, stock and alerts',
  'مبيعات اليوم':'Today Sales','إجمالي قيمة الفواتير':'Total invoice value','مجمل الربح':'Gross Profit','قبل مصروفات التشغيل':'Before operating expenses','مصروفات اليوم':'Today Expenses','مصروفات تشغيل مسجلة':'Recorded operating expenses','صافي الربح':'Net Profit','المبيعات - التكلفة - المصروفات':'Sales - COGS - expenses','عدد الطلبات':'Orders','طلبات اليوم':'Today orders','متوسط الفاتورة':'Average Ticket','المبيعات ÷ عدد الطلبات':'Sales ÷ orders','قيمة المخزون':'Inventory Value','الكمية × تكلفة الوحدة':'Qty × unit cost','تنبيهات مخزون':'Stock Alerts',
  'آخر عمليات البيع':'Recent Sales','الوقت':'Time','الطلب · الكمية × سعر الوحدة':'Order · Qty × Unit Price','الإجمالي':'Total','قيمة المخزون الحالية':'Current Inventory Value','بيع جديد':'New Sale','تسجيل توريد':'Record Purchase',
  'الطلب الحالي':'Current Order','نوع الطلب':'Order Type','طريقة الدفع':'Payment Method','السلة فاضية':'Cart is empty','تأكيد البيع':'Complete Sale','دوّري على صنف...':'Search products...',
  'إضافة مادة خام جديدة':'Add Raw Material','اسم المادة':'Material name','الكمية الحالية':'Current quantity','الحد الأدنى':'Minimum level','تكلفة الوحدة':'Unit cost','إضافة':'Add','مواد خام (للمشروبات والحلويات)':'Raw Materials','الصنف':'Item','الكمية المتاحة':'Available Qty','الحالة':'Status','توريد سريع':'Quick Restock','بن معبأ جاهز للبيع':'Packaged Coffee for Sale','عدد العبوات':'Pack Qty','إضافة بن معبأ جاهز':'Add Packaged Coffee','سعر البيع':'Selling price','تكلفة العبوة':'Pack cost','الكمية':'Quantity','تسجيل هالك / تلف':'Record Waste / Damage','مادة خام':'Raw material','منتج بن معبأ':'Packaged coffee','الكمية التالفة':'Waste quantity','تسجيل الهالك':'Record Waste',
  'المشتريات والموردين':'Purchases & Suppliers','الموردين':'Suppliers','اسم المورد':'Supplier name','رقم التليفون':'Phone','تسجيل عملية شراء':'Record Purchase','نوع الصنف':'Item type','المورد':'Supplier','بدون مورد محدد':'No supplier','مصروفات التشغيل':'Operating Expenses','تسجيل مصروف':'Record Expense','آخر عمليات الشراء':'Recent Purchases','التاريخ':'Date','القيمة':'Amount','النوع':'Type','الملاحظة':'Note',
  'إدارة المنتجات والفئات':'Products & Categories','الفئات':'Categories','اسم فئة جديدة':'New category name','المنتجات':'Products','إضافة منتج جديد':'Add Product','كل المنتجات':'All Products','الاسم':'Name','الفئة':'Category','السعر':'Price','التكلفة':'Cost','الهامش':'Margin','مفعّل':'Active','متوقف':'Inactive','جاهز':'Retail','يُحضّر':'Prepared',
  'التقارير':'Reports','تصدير CSV':'Export CSV','يومي':'Daily','أسبوعي':'Weekly','شهري':'Monthly','إجمالي المبيعات':'Total Sales','تكلفة البضاعة المباعة':'COGS','هامش صافي الربح':'Net Margin','أعلى صنف مبيعًا':'Top-selling Product','المبيعات حسب الفئة':'Sales by Category','أفضل 5 منتجات في الفترة دي':'Top 5 Products','المنتج':'Product','الكمية المباعة':'Qty Sold',
  'الحسابات':'Accounts','إضافة مستخدم':'Add User','اسم المستخدم':'Username','كلمة المرور':'Password','الدور':'Role','كاشير':'Cashier','مانجر':'Manager','إضافة الحساب':'Add Account','تهيئة النظام':'Reset Demo Data',
  'تسجيل الدخول':'Sign in','استخدم حساب المدير أو الكاشير لتجربة اختلاف الصلاحيات.':'Use the manager or cashier account to test role-based access.','دخول للنظام':'Sign in','حسابات الدخول الافتراضية':'Default sign-in accounts','كل التشغيل في شاشة واحدة.':'Everything you need to run the shop, in one screen.','صلاحيات منفصلة للمدير والكاشير':'Separate manager and cashier permissions','فروع + مبيعات مرتبطة بالمستخدم والفرع':'Branch-aware sales tied to each user',
  'متوفر':'In Stock','قارب على النفاد':'Low Stock','لا يوجد بيانات في الفترة دي.':'No data for this period.','لسه مفيش عمليات بيع النهاردة.':'No sales yet today.','تم البيع بنجاح':'Sale completed','تم تسجيل عملية الشراء':'Purchase recorded','تم تسجيل المصروف':'Expense recorded','تم تحديث المخزون':'Inventory updated','إغلاق':'Close','حفظ':'Save','إلغاء':'Cancel','حذف':'Delete'
};
const UI_TEXT_REV = Object.fromEntries(Object.entries(UI_TEXT).map(([a,e])=>[e,a]));
function loc(){ return currentLang==='ar' ? 'ar-EG-u-nu-latn' : 'en-GB'; }
function txt(ar,en){ return currentLang==='ar'?ar:en; }
function objName(o){ if(!o) return '—'; return currentLang==='ar' ? (o.name||o.nameEn||'—') : (o.nameEn||o.name||'—'); }
function unitName(o){ return currentLang==='ar' ? (o.unit||o.unitEn||'') : (o.unitEn||o.unit||''); }
function branchName(id){ const b=state.branches?.find(x=>x.id===id); return b?objName(b):id; }
function roleName(r){ return r==='manager'?txt('مانجر','Manager'):txt('كاشير','Cashier'); }
function currency(){ return currentLang==='ar'?'ج.م':'EGP'; }
function num(n,digits=0){ return Number(n||0).toLocaleString('en-US',{minimumFractionDigits:digits,maximumFractionDigits:digits}); }
function fmt(n){ return `${num(Math.round(n))} ${currency()}`; }
function translateNodeText(value,target){
  const raw=value, trimmed=raw.trim(); if(!trimmed) return value;
  const map=target==='en'?UI_TEXT:UI_TEXT_REV; let v=map[trimmed];
  if(!v){
    if(target==='en'){
      v=trimmed.replace(/^الأكثر مبيعًا:\s*/,'Top seller: ').replace(/ أصناف$/,' items').replace(/ منتج$/,' products');
      if(v===trimmed) v=null;
    }else{
      v=trimmed.replace(/^Top seller:\s*/,'الأكثر مبيعًا: ').replace(/ items$/,' أصناف').replace(/ products$/,' منتج');
      if(v===trimmed) v=null;
    }
  }
  if(!v) return value;
  return raw.replace(trimmed,v);
}
function applyLanguage(root=document.body){
  document.documentElement.lang=currentLang; document.documentElement.dir=currentLang==='ar'?'rtl':'ltr';
  const walker=document.createTreeWalker(root,NodeFilter.SHOW_TEXT); const nodes=[]; while(walker.nextNode()) nodes.push(walker.currentNode);
  nodes.forEach(n=>{ if(n.parentElement && !['SCRIPT','STYLE'].includes(n.parentElement.tagName)) n.nodeValue=translateNodeText(n.nodeValue,currentLang==='en'?'en':'ar'); });
  root.querySelectorAll?.('[placeholder]').forEach(el=>{el.placeholder=translateNodeText(el.placeholder,currentLang==='en'?'en':'ar').trim()});
  const lb=document.getElementById('lang-btn'), ll=document.getElementById('login-lang-btn'); if(lb) lb.textContent=currentLang==='ar'?'EN':'AR'; if(ll) ll.textContent=currentLang==='ar'?'EN':'AR';
  setHeroDate();
}
function toggleLanguage(){ currentLang=currentLang==='ar'?'en':'ar'; localStorage.setItem('coffeeSpaceLang_v1',currentLang); renderAllForLanguage(); }
function renderAllForLanguage(){
  renderPos(); renderCart(); renderTables(); renderDashboard(); renderInventory(); renderAdmin(); renderReports(); renderPurchasesPage(); if(document.getElementById('page-users')) renderUsers(); updateSessionUI(); applyLanguage();
}
function quickLogin(username,password){
  document.getElementById('login-username').value=username;
  document.getElementById('login-password').value=password;
  login();
}
function login(){
  const u=document.getElementById('login-username').value.trim(); const p=document.getElementById('login-password').value;
  const found=(state.users||[]).find(x=>x.active!==false && x.username===u && x.password===p);
  const err=document.getElementById('login-error');
  if(!found){err.style.display='block';err.textContent=txt('اسم المستخدم أو كلمة المرور غير صحيحة.','Incorrect username or password.');return;}
  currentUser=found; sessionStorage.setItem('coffeeSpaceUser_v1',found.id); document.getElementById('login-shell').classList.add('hidden'); document.querySelector('.app').classList.remove('auth-hidden'); document.body.classList.remove('locked');
  applyPermissions(); updateSessionUI(); goToPage('dashboard'); renderAllForLanguage();
}
function logout(){ sessionStorage.removeItem('coffeeSpaceUser_v1'); currentUser=null; document.getElementById('login-shell').classList.remove('hidden'); document.querySelector('.app').classList.add('auth-hidden'); document.body.classList.add('locked'); applyLanguage(); }
function restoreSession(){ const id=sessionStorage.getItem('coffeeSpaceUser_v1'); const u=(state.users||[]).find(x=>x.id===id&&x.active!==false); if(u){currentUser=u;document.getElementById('login-shell').classList.add('hidden');document.querySelector('.app').classList.remove('auth-hidden');document.body.classList.remove('locked');applyPermissions();updateSessionUI();}else{document.querySelector('.app').classList.add('auth-hidden');} }
function applyPermissions(){ const isManager=currentUser?.role==='manager'; document.querySelectorAll('.manager-nav,.manager-only').forEach(el=>el.classList.toggle('role-hidden',!isManager)); if(!isManager && ['tables','inventory','purchases','admin','reports','users','customers','stockops','finance','operations','erp-settings'].includes(document.querySelector('.nav-item.active')?.dataset.page)) goToPage('dashboard'); }
function updateSessionUI(){
  if(!currentUser) return; document.getElementById('session-name').textContent=currentLang==='ar'?(currentUser.name||currentUser.nameEn):(currentUser.nameEn||currentUser.name); document.getElementById('session-user').textContent='@'+currentUser.username;
  const role=document.getElementById('session-role'); role.textContent=roleName(currentUser.role); role.className='role-badge '+(currentUser.role==='cashier'?'cashier':''); document.getElementById('session-avatar').textContent=(currentUser.nameEn||currentUser.name||'U').trim()[0].toUpperCase();
  const sel=document.getElementById('branch-select'); if(sel){ sel.value=currentBranch; [...sel.options].forEach(opt=>{const b=state.branches.find(x=>x.id===opt.value);if(b)opt.textContent=`${objName(b)} · ${opt.value==='tagamoa'?'Tagamoa':'Bab El Louq'}`;}); }
}
function changeBranch(id){currentBranch=id;sessionStorage.setItem('coffeeSpaceBranch_v1',id);renderDashboard();renderReports();showToast(txt('تم تغيير الفرع','Branch changed'),'ic-store');}
function renderUsers(){
  const w=document.getElementById('users-list'); if(!w) return; w.innerHTML=(state.users||[]).map(u=>`<div class="user-list-card"><div class="u-main"><div class="u-avatar">${(u.nameEn||u.name||'U')[0]}</div><div><b>${currentLang==='ar'?(u.name||u.nameEn):(u.nameEn||u.name)}</b><small>@${u.username} · ${roleName(u.role)}</small></div></div><div class="btn-row"><span class="pill ${u.active===false?'muted':'ok'}">${u.active===false?txt('متوقف','Inactive'):txt('مفعّل','Active')}</span>${u.id!=='u_manager'?`<button class="btn btn-ghost btn-icon" onclick="toggleUser('${u.id}')">${u.active===false?'✓':'⏸'}</button>`:''}</div></div>`).join(''); applyLanguage(w);
}
function addUser(){ const name=document.getElementById('user-name').value.trim(),username=document.getElementById('user-username').value.trim(),password=document.getElementById('user-password').value.trim(),role=document.getElementById('user-role').value; if(!name||!username||!password){alert(txt('كمّلي الاسم واسم المستخدم وكلمة المرور.','Complete name, username and password.'));return;} if(state.users.some(u=>u.username.toLowerCase()===username.toLowerCase())){alert(txt('اسم المستخدم مستخدم بالفعل.','Username already exists.'));return;} state.users.push({id:'u_'+Date.now(),name,nameEn:name,username,password,role,active:true}); saveState(); ['user-name','user-username','user-password'].forEach(id=>document.getElementById(id).value=''); renderUsers(); showToast(txt('تمت إضافة المستخدم','User added'),'ic-check'); }
function toggleUser(id){const u=state.users.find(x=>x.id===id);if(!u)return;u.active=u.active===false?true:false;saveState();renderUsers();}
function resetDemoData(){ if(!confirm(txt('إعادة النظام للوضع الافتراضي؟ سيتم حذف كل الحركات المسجلة.','Reset the system to defaults? All recorded transactions will be deleted.')))return; state=defaultState();saveState();currentUser=state.users.find(u=>u.username==='manager');sessionStorage.setItem('coffeeSpaceUser_v1',currentUser.id);renderAllForLanguage();showToast(txt('تمت تهيئة النظام','System reset'),'ic-check'); }
/* =========================================================
   NAV
   ========================================================= */
document.querySelectorAll('.nav-item').forEach(el=>{
  el.addEventListener('click', ()=>{
    if(el.classList.contains('manager-nav') && currentUser?.role!=='manager') return;
    document.querySelectorAll('.nav-item').forEach(n=>n.classList.remove('active'));
    document.querySelectorAll('.page').forEach(p=>p.classList.remove('active'));
    el.classList.add('active');
    document.getElementById('page-'+el.dataset.page).classList.add('active');
    if(el.dataset.page==='tables'){ renderTables(); }
    if(el.dataset.page==='inventory'){ renderInventory(); populateWasteItems(); }
    if(el.dataset.page==='dashboard') renderDashboard();
    if(el.dataset.page==='admin') renderAdmin();
    if(el.dataset.page==='reports') renderReports();
    if(el.dataset.page==='pos') renderPos();
    if(el.dataset.page==='purchases'){ renderPurchasesPage(); }
    if(el.dataset.page==='users'){ renderUsers(); }
    if(el.dataset.page==='customers'){ renderCustomers(); }
    if(el.dataset.page==='stockops'){ populateStockOps(); }
    if(el.dataset.page==='finance'){ renderFinance(); }
    if(el.dataset.page==='operations'){ renderOperations(); }
    if(el.dataset.page==='erp-settings'){ renderAudit(); }
    applyLanguage(document.getElementById('page-'+el.dataset.page));
  });
});

/* =========================================================
   HELPERS
   ========================================================= */
// num() and fmt() are defined in the V8 bilingual layer above.
function showToast(msg, icon){
  const t = document.getElementById('toast');
  const shown = currentLang==='en' ? (UI_TEXT[msg]||msg) : (UI_TEXT_REV[msg]||msg);
  t.innerHTML = `<svg><use href="#${icon||'ic-check'}"/></svg><span>${shown}</span>`;
  t.classList.add('show');
  setTimeout(()=>t.classList.remove('show'), 2200);
}
function categoryOf(id){ return state.categories.find(c=>c.id===id); }
function goToPage(page){
  const el=document.querySelector(`.nav-item[data-page="${page}"]`);
  if(el) el.click();
}
function inventoryValue(){
  const raw=Object.values(state.rawMaterials).reduce((s,m)=>s+(Number(m.quantity)||0)*(Number(m.unitCost)||0),0);
  const retail=Object.values(state.products).filter(p=>p.kind==='retail').reduce((s,p)=>s+(Number(p.stock?.quantity)||0)*(Number(p.cost)||0),0);
  return {raw,retail,total:raw+retail};
}


function maxPossible(product){
  if(product.kind==='prepared'){
    let max = Infinity;
    for(const [matId, amt] of Object.entries(product.recipe)){
      const mat = state.rawMaterials[matId];
      if(!mat) continue;
      max = Math.min(max, Math.floor(mat.quantity/amt));
    }
    return max===Infinity ? 0 : max;
  }
  return product.stock.quantity;
}

function setHeroDate(){
  const now=new Date(); const dateEl=document.getElementById('hero-date'); if(dateEl) dateEl.textContent=now.toLocaleDateString(loc(),{weekday:'long',day:'numeric',month:'long',year:'numeric'});
  const greet=document.getElementById('hero-greet'); if(greet) greet.textContent=currentUser?`${txt('أهلاً','Welcome')}, ${currentLang==='ar'?(currentUser.name||currentUser.username):(currentUser.nameEn||currentUser.username)} ☕`:`${txt('أهلاً بك في Coffee Space','Welcome to Coffee Space')} ☕`;
}

/* =========================================================
   FLOOR / TABLES
   ========================================================= */
function tableAreaName(area){ return area==='outdoor'?txt('خارجي','Outdoor'):txt('داخلي','Indoor'); }
function addTable(){
  const name=document.getElementById('table-name')?.value.trim();
  const seats=Math.max(1,parseInt(document.getElementById('table-seats')?.value||'0',10));
  const area=document.getElementById('table-area')?.value||'indoor';
  if(!name){alert(txt('اكتبي رقم أو اسم الترابيزة.','Enter a table number or name.'));return;}
  if((state.tables||[]).some(t=>t.name.toLowerCase()===name.toLowerCase())){alert(txt('اسم الترابيزة موجود بالفعل.','This table name already exists.'));return;}
  state.tables.push({id:'tbl_'+Date.now(),name,seats,area,active:true}); saveState(); audit('table.created',name);
  document.getElementById('table-name').value=''; document.getElementById('table-seats').value='4'; renderTables(); populatePosTables();
  showToast(txt('تمت إضافة الترابيزة','Table added'),'ic-check');
}
function toggleTable(id){const t=state.tables.find(x=>x.id===id);if(!t)return;t.active=!t.active;saveState();audit('table.status',`${t.name} · ${t.active?'active':'inactive'}`);renderTables();populatePosTables();}
function deleteTable(id){const t=state.tables.find(x=>x.id===id);if(!t)return;if(!confirm(txt(`حذف الترابيزة ${t.name}؟`,`Delete table ${t.name}?`)))return;state.tables=state.tables.filter(x=>x.id!==id);saveState();audit('table.deleted',t.name);renderTables();populatePosTables();}
function renderTables(){
  const grid=document.getElementById('tables-grid'), summary=document.getElementById('table-summary'); if(!grid)return;
  const tables=state.tables||[], active=tables.filter(t=>t.active);
  if(summary) summary.innerHTML=`<div class="table-stat"><b>${num(tables.length)}</b><span>${txt('إجمالي الترابيزات','Total tables')}</span></div><div class="table-stat"><b>${num(active.length)}</b><span>${txt('متاحة للطلبات','Available for orders')}</span></div><div class="table-stat"><b>${num(active.reduce((a,t)=>a+(+t.seats||0),0))}</b><span>${txt('إجمالي الكراسي','Total seats')}</span></div>`;
  grid.innerHTML=tables.length?tables.map(t=>`<div class="floor-table ${t.active?'':'inactive'}"><div class="table-top"><span class="table-number">${t.name}</span><span class="table-area">${tableAreaName(t.area)}</span></div><div class="table-visual"><div class="chair c1"></div><div class="chair c2"></div><div class="table-disc">☕</div><div class="chair c3"></div><div class="chair c4"></div></div><div class="table-seat-count"><b>${num(t.seats)}</b> ${txt('كراسي','seats')}</div><div class="table-actions"><button class="btn btn-ghost" onclick="toggleTable('${t.id}')">${t.active?txt('إيقاف','Disable'):txt('تفعيل','Enable')}</button><button class="btn btn-danger" onclick="deleteTable('${t.id}')">${txt('حذف','Delete')}</button></div></div>`).join(''):`<div class="empty-state">${txt('لسه مفيش ترابيزات. أضيفي أول ترابيزة من فوق.','No tables yet. Add your first table above.')}</div>`;
  applyLanguage(grid); populatePosTables();
}
function populatePosTables(){
  const sel=document.getElementById('pos-table'); if(!sel)return; const current=sel.value;
  const tables=(state.tables||[]).filter(t=>t.active);
  sel.innerHTML=`<option value="">${txt('اختاري الترابيزة','Select table')}</option>`+tables.map(t=>`<option value="${t.id}">${t.name} · ${num(t.seats)} ${txt('كراسي','seats')} · ${tableAreaName(t.area)}</option>`).join('');
  if(tables.some(t=>t.id===current))sel.value=current;
}
function handleOrderTypeChange(){const dine=document.getElementById('order-type')?.value==='dinein';const wrap=document.getElementById('table-select-wrap');if(wrap)wrap.style.display=dine?'block':'none';populatePosTables();}

/* =========================================================
   POS
   ========================================================= */
function renderPos(){
  handleOrderTypeChange();
  const wrap = document.getElementById('pos-groups');
  const query = (document.getElementById('pos-search')?.value || '').trim();
  wrap.innerHTML = '';

  state.categories.forEach(cat=>{
    const products = Object.values(state.products).filter(p=>
      p.active && p.categoryId===cat.id && (!query || p.name.includes(query))
    );
    if(products.length===0) return;

    const title = document.createElement('div');
    title.className = 'group-title';
    title.innerHTML = `<svg style="color:var(--amber-deep)"><use href="#${cat.icon}"/></svg> ${objName(cat)}`;
    wrap.appendChild(title);

    const grid = document.createElement('div');
    grid.className = 'items-grid';
    products.forEach(p=>{
      const avail = maxPossible(p) - (cart[p.id]?.qty||0);
      const disabled = avail<=0;
      const card = document.createElement('div');
      card.className = 'item-card' + (disabled?' disabled':'');
      const note = p.kind==='retail' ? `متاح: ${avail} عبوة` : (disabled?'المخزون غير كافٍ':'متاح');
      const icon = p.kind==='retail' ? 'ic-bean' : (cat.icon||'ic-cup');
      card.innerHTML = `<svg class="item-icon"><use href="#${icon}"/></svg><div class="name">${objName(p)}</div><div class="price">${fmt(p.price)}</div><div class="stock-note">${note}</div>`;
      if(!disabled) card.addEventListener('click', ()=>addToCart(p.id));
      grid.appendChild(card);
    });
    wrap.appendChild(grid);
  });

  if(wrap.innerHTML===''){ wrap.innerHTML = '<div class="empty-note">مفيش أصناف مطابقة للبحث.</div>'; }
}

function addToCart(id){
  if(!cart[id]) cart[id] = { qty:0 };
  cart[id].qty += 1;
  renderCart(); renderPos();
}
function changeQty(id, delta){
  if(!cart[id]) return;
  cart[id].qty += delta;
  if(cart[id].qty<=0) delete cart[id];
  renderCart(); renderPos();
}

function renderCart(){
  const container = document.getElementById('cart-items');
  const ids = Object.keys(cart);
  const btn = document.getElementById('checkout-btn');
  if(ids.length===0){
    container.innerHTML = '<div class="empty-cart">السلة فاضية</div>';
    btn.disabled = true;
    document.getElementById('cart-total').textContent = fmt(0);
    return;
  }
  let total = 0;
  container.innerHTML = ids.map(id=>{
    const p = state.products[id];
    const qty = cart[id].qty;
    total += p.price*qty;
    return `<div class="cart-row"><div class="cart-row-main"><span>${objName(p)}</span><div class="line-total">${num(qty)} × ${fmt(p.price)} = <b>${fmt(p.price*qty)}</b></div></div><div class="qty-ctrl"><button class="qty-btn" onclick="changeQty('${id}',-1)">−</button><span class="qty-number">${num(qty)}</span><button class="qty-btn" onclick="changeQty('${id}',1)">+</button></div></div>`;
  }).join('');
  document.getElementById('cart-total').textContent = fmt(total);
  btn.disabled = false;
}

document.getElementById('checkout-btn').addEventListener('click', ()=>{
  const ids = Object.keys(cart);
  if(ids.length===0) return;
  const orderType = document.getElementById('order-type')?.value || 'takeaway';
  const paymentMethod = document.getElementById('payment-method')?.value || 'cash';
  const tableId = orderType==='dinein' ? (document.getElementById('pos-table')?.value||'') : '';
  if(orderType==='dinein' && !tableId){ alert(txt('اختاري الترابيزة قبل تأكيد الطلب.','Select a table before completing the order.')); return; }
  const table = (state.tables||[]).find(t=>t.id===tableId);
  let total = 0;
  const ts = Date.now();
  const items = [];

  ids.forEach(id=>{
    const p = state.products[id];
    const qty = cart[id].qty;
    total += p.price*qty;
    const cost = computeProductCost(p);

    if(p.kind==='prepared'){
      for(const [matId, amt] of Object.entries(p.recipe)){ state.rawMaterials[matId].quantity -= amt*qty; }
    } else {
      p.stock.quantity -= qty;
    }
    items.push({ productId:id, name:p.name, nameEn:p.nameEn, categoryId:p.categoryId, qty, price:p.price, cost, total:p.price*qty });
  });

  const orderId = (state.salesLog[state.salesLog.length-1]?.id || 0) + 1;
  state.salesLog.push({ id: orderId, ts, items, total, orderType, paymentMethod, tableId:tableId||null, tableName:table?.name||'', tableSeats:table?.seats||null, userId:currentUser?.id||null, userName:currentUser?.name||'', userNameEn:currentUser?.nameEn||'', branch:currentBranch });
  audit('sale.completed', `#${orderId} · ${total}`);
  saveState();

  showReceipt(items, total, ts, orderId, orderType, paymentMethod, tableId);
  cart = {};
  renderCart(); renderPos(); renderInventory(); renderDashboard();
});

function showReceipt(items, total, ts, orderId, orderType, paymentMethod, tableId){
  const time = new Date(ts).toLocaleTimeString(loc(),{hour:'2-digit',minute:'2-digit'});
  const rows = items.map(it=>`<div class="receipt-row"><span>${it.name} × ${it.qty}</span><span>${fmt(it.total)}</span></div>`).join('');
  document.getElementById('receipt-content').innerHTML = `
    <div class="receipt-head"><div class="rname">${txt('Coffee Space','Coffee Space')}</div><div class="rmeta">${txt('فاتورة رقم','Invoice')} #${num(orderId)} — ${time}</div><div class="rmeta">${branchName(currentBranch)} · ${orderType==='dinein'?'Dine-in':'Takeaway'}${orderType==='dinein'&&tableId?' · '+((state.tables||[]).find(t=>t.id===tableId)?.name||''):''} · ${paymentMethod==='card'?'Card':paymentMethod==='wallet'?'Wallet':'Cash'} · ${currentUser?((currentLang==='ar'?currentUser.name:currentUser.nameEn)||currentUser.username):''}</div></div>
    <div class="receipt-dash"></div>${rows}
    <div class="receipt-total"><span>الإجمالي</span><span>${fmt(total)}</span></div>
    <button class="receipt-close" onclick="closeReceipt()">تمام، عملية جديدة</button>`;
  document.getElementById('receipt-overlay').classList.add('show');
}
function closeReceipt(){
  document.getElementById('receipt-overlay').classList.remove('show');
  showToast('تم البيع بنجاح', 'ic-check');
}

/* =========================================================
   INVENTORY
   ========================================================= */
function statusPill(qty,min){return qty<=min?`<span class="pill warn"><svg width="11" height="11"><use href="#ic-alert"/></svg>${txt('قارب على النفاد','Low Stock')}</span>`:`<span class="pill ok"><svg width="11" height="11"><use href="#ic-check"/></svg>${txt('متوفر','In Stock')}</span>`;}

function renderInventory(){
  const rawBody = document.getElementById('raw-materials-body');
  rawBody.innerHTML = Object.entries(state.rawMaterials).map(([key,m])=>`
    <tr>
      <td>${objName(m)}</td><td>${num(m.quantity)} ${unitName(m)}</td><td>${num(m.min)} ${unitName(m)}</td>
      <td>${fmt(m.unitCost||0)}</td><td>${fmt((m.quantity||0)*(m.unitCost||0))}</td>
      <td>${statusPill(m.quantity,m.min)}</td>
      <td><button class="btn btn-ghost" onclick="quickRestock('raw','${key}')"><svg width="12" height="12"><use href="#ic-truck"/></svg>توريد سريع</button></td>
    </tr>`).join('');

  const retailBody = document.getElementById('retail-stock-body');
  const retailProducts = Object.values(state.products).filter(p=>p.kind==='retail');
  retailBody.innerHTML = retailProducts.map(p=>`
    <tr>
      <td>${p.name}</td><td>${num(p.stock.quantity)} عبوة</td><td>${num(p.stock.min)} عبوة</td>
      <td>${fmt(p.cost||0)}</td><td>${fmt((p.stock.quantity||0)*(p.cost||0))}</td>
      <td>${statusPill(p.stock.quantity,p.stock.min)}</td>
      <td><button class="btn btn-ghost" onclick="quickRestock('retail','${p.id}')"><svg width="12" height="12"><use href="#ic-truck"/></svg>توريد سريع</button></td>
    </tr>`).join('');

}

function quickRestock(type, key){
  const amount = prompt('أدخل الكمية الواردة (توريد سريع بدون تسجيل مورد أو تكلفة):');
  const n = parseFloat(amount);
  if(!n || n<=0) return;
  if(type==='raw'){ state.rawMaterials[key].quantity += n; }
  else { state.products[key].stock.quantity += n; }
  saveState();
  renderInventory(); renderPos(); renderDashboard(); renderAdmin();
  showToast('تم تحديث المخزون', 'ic-truck');
}

function addRawMaterial(){
  const name = document.getElementById('new-mat-name').value.trim();
  const unit = document.getElementById('new-mat-unit').value.trim();
  const qty = parseFloat(document.getElementById('new-mat-qty').value)||0;
  const min = parseFloat(document.getElementById('new-mat-min').value)||0;
  const cost = parseFloat(document.getElementById('new-mat-cost').value)||0;
  if(!name || !unit){ alert('اكتبي اسم المادة والوحدة على الأقل.'); return; }
  const id = 'mat_' + Date.now();
  state.rawMaterials[id] = { name, unit, quantity:qty, min, unitCost:cost };
  saveState();
  ['new-mat-name','new-mat-unit','new-mat-qty','new-mat-min','new-mat-cost'].forEach(i=>document.getElementById(i).value='');
  renderInventory();
  showToast('تمت إضافة المادة الخام', 'ic-check');
}

function addRetailProduct(){
  const name=document.getElementById('new-retail-name').value.trim();
  const price=parseFloat(document.getElementById('new-retail-price').value);
  const cost=parseFloat(document.getElementById('new-retail-cost').value);
  const qty=parseFloat(document.getElementById('new-retail-qty').value)||0;
  const min=parseFloat(document.getElementById('new-retail-min').value)||0;
  if(!name||!price||price<=0||isNaN(cost)||cost<0){alert('اكتبي اسم البن وسعر البيع والتكلفة بشكل صحيح.');return;}
  const cat=state.categories.find(c=>c.id==='beans')||state.categories.find(c=>c.name.includes('بن'))||state.categories[0];
  const id='retail_'+Date.now();
  state.products[id]={id,name,categoryId:cat.id,kind:'retail',price,cost,active:true,stock:{quantity:qty,min},recipe:{}};
  saveState();
  ['new-retail-name','new-retail-price','new-retail-cost','new-retail-qty','new-retail-min'].forEach(i=>document.getElementById(i).value='');
  renderInventory();renderAdmin();renderPos();renderDashboard();
  showToast('تمت إضافة البن المعبأ','ic-check');
}

function populateWasteItems(){
  const type = document.getElementById('waste-item-type').value;
  const sel = document.getElementById('waste-item');
  if(type==='raw'){
    sel.innerHTML = Object.entries(state.rawMaterials).map(([id,m])=>`<option value="${id}">${objName(m)}</option>`).join('');
  } else {
    sel.innerHTML = Object.values(state.products).filter(p=>p.kind==='retail').map(p=>`<option value="${p.id}">${objName(p)}</option>`).join('');
  }
}

function recordWaste(){
  const itemType = document.getElementById('waste-item-type').value;
  const itemId = document.getElementById('waste-item').value;
  const qty = parseFloat(document.getElementById('waste-qty').value);
  const reason = document.getElementById('waste-reason').value.trim();
  if(!itemId || !qty || qty<=0){ alert('اختاري الصنف واكتبي كمية صحيحة.'); return; }

  let itemName, unitCost;
  if(itemType==='raw'){
    const mat = state.rawMaterials[itemId];
    if(qty>mat.quantity){ alert('الكمية أكبر من المتاح في المخزون.'); return; }
    mat.quantity -= qty; itemName = mat.name; unitCost = mat.unitCost||0;
  } else {
    const p = state.products[itemId];
    if(qty>p.stock.quantity){ alert('الكمية أكبر من المتاح في المخزون.'); return; }
    p.stock.quantity -= qty; itemName = p.name; unitCost = p.cost||0;
  }

  const id = (state.waste[state.waste.length-1]?.id||0)+1;
  state.waste.push({ id, ts:Date.now(), itemType, itemId, itemName, quantity:qty, reason: reason||'—', value: qty*unitCost });
  saveState();
  renderInventory(); renderPos(); renderDashboard();
  document.getElementById('waste-qty').value=''; document.getElementById('waste-reason').value='';
  showToast('تم تسجيل الهالك', 'ic-trash');
}

/* =========================================================
   PURCHASES + SUPPLIERS
   ========================================================= */
function renderSuppliersList(){
  const wrap = document.getElementById('suppliers-list');
  wrap.innerHTML = state.suppliers.map(s=>`
    <div class="cat-row">
      <span><b>${currentLang==='ar'?(s.name||s.nameEn):(s.nameEn||s.name)}</b><br><span style="color:var(--ink-soft);font-size:11.5px">${s.phone||'—'} ${s.notes?'· '+s.notes:''}</span></span>
      <div class="btn-row"><button class="btn btn-ghost btn-icon" onclick="editSupplier('${s.id}')"><svg width="13" height="13"><use href="#ic-edit"/></svg></button><button class="btn btn-danger btn-icon" onclick="deleteSupplier('${s.id}')"><svg width="13" height="13"><use href="#ic-trash"/></svg></button></div>
    </div>`).join('') || `<div style="color:var(--ink-soft);font-size:13px">لسه مفيش موردين مضافين.</div>`;
}

function addSupplier(){
  const name = document.getElementById('sup-name').value.trim();
  const phone = document.getElementById('sup-phone').value.trim();
  const notes = document.getElementById('sup-notes').value.trim();
  if(!name) return;
  const id = 'sup_' + Date.now();
  state.suppliers.push({ id, name, phone, notes });
  saveState();
  document.getElementById('sup-name').value=''; document.getElementById('sup-phone').value=''; document.getElementById('sup-notes').value='';
  renderPurchasesPage();
  showToast('تمت إضافة المورد', 'ic-check');
}

function editSupplier(id){
  const s=state.suppliers.find(x=>x.id===id);
  if(!s) return;
  document.getElementById('sup-name').value=s.name||'';
  document.getElementById('sup-phone').value=s.phone||'';
  document.getElementById('sup-notes').value=s.notes||'';
  const btn=document.querySelector('[onclick="addSupplier()"]');
  if(btn){btn.innerHTML='<svg width="13" height="13"><use href="#ic-check"/></svg> حفظ التعديل';btn.setAttribute('onclick',`saveSupplierEdit('${id}')`);}
}

function saveSupplierEdit(id){
  const s=state.suppliers.find(x=>x.id===id);
  if(!s) return;
  const name=document.getElementById('sup-name').value.trim();
  if(!name){alert('اكتبي اسم المورد.');return;}
  s.name=name;s.phone=document.getElementById('sup-phone').value.trim();s.notes=document.getElementById('sup-notes').value.trim();
  saveState();renderPurchasesPage();showToast('تم تعديل المورد','ic-check');
}

function deleteSupplier(id){
  if(!confirm('متأكدة من حذف المورد ده؟')) return;
  state.suppliers = state.suppliers.filter(s=>s.id!==id);
  saveState();
  renderPurchasesPage();
}

function onPurchaseTypeChange(){
  const type = document.querySelector('input[name="pur-type"]:checked').value;
  document.getElementById('opt-pur-raw').classList.toggle('selected', type==='raw');
  document.getElementById('opt-pur-retail').classList.toggle('selected', type==='retail');
  populatePurchaseItems();
}

function populatePurchaseItems(){
  const type = document.querySelector('input[name="pur-type"]:checked').value;
  const sel = document.getElementById('pur-item');
  if(type==='raw'){
    sel.innerHTML = Object.entries(state.rawMaterials).map(([id,m])=>`<option value="${id}">${objName(m)}</option>`).join('');
  } else {
    sel.innerHTML = Object.values(state.products).filter(p=>p.kind==='retail').map(p=>`<option value="${p.id}">${objName(p)}</option>`).join('');
  }
}

function renderPurchasesPage(){
  renderSuppliersList();
  renderExpenses();
  const supSel = document.getElementById('pur-supplier');
  supSel.innerHTML = '<option value="">بدون مورد محدد</option>' + state.suppliers.map(s=>`<option value="${s.id}">${currentLang==='ar'?(s.name||s.nameEn):(s.nameEn||s.name)}</option>`).join('');
  populatePurchaseItems();

  const body = document.getElementById('purchases-body');
  const recent = [...state.purchases].sort((a,b)=>b.ts-a.ts).slice(0,15);
  body.innerHTML = recent.map(p=>{
    const date = new Date(p.ts).toLocaleDateString(loc(),{ day:'2-digit', month:'2-digit', year:'numeric' });
    return `<tr><td>${date}</td><td>${p.itemName}</td><td>${p.supplierName}</td><td><span class="qty-number">${num(p.quantity)}</span></td><td>${fmt(p.unitCost)}</td><td>${fmt(p.totalCost)}</td></tr>`;
  }).join('') || `<tr><td colspan="6" style="color:var(--ink-soft)">لسه مفيش عمليات شراء مسجلة.</td></tr>`;
}

function renderExpenses(){
  const body=document.getElementById('expenses-body');
  if(!body) return;
  const rows=[...state.expenses].sort((a,b)=>b.ts-a.ts).slice(0,12);
  body.innerHTML=rows.map(e=>`<tr><td>${new Date(e.ts).toLocaleDateString(loc())}</td><td><span class="expense-chip">${e.category}</span></td><td>${e.note||'—'}</td><td>${fmt(e.amount)}</td><td><button class="btn btn-danger btn-icon" onclick="deleteExpense('${e.id}')"><svg width="12" height="12"><use href="#ic-trash"/></svg></button></td></tr>`).join('') || `<tr><td colspan="5" style="color:var(--ink-soft)">لسه مفيش مصروفات تشغيل مسجلة.</td></tr>`;
}
function recordExpense(){
  const category=document.getElementById('expense-category').value;
  const amount=parseFloat(document.getElementById('expense-amount').value);
  const note=document.getElementById('expense-note').value.trim();
  if(!amount || amount<=0){ alert('اكتبي قيمة مصروف صحيحة.'); return; }
  state.expenses.push({id:'exp_'+Date.now(),ts:Date.now(),category,amount,note});
  document.getElementById('expense-amount').value=''; document.getElementById('expense-note').value='';
  saveState(); renderExpenses(); renderDashboard(); renderReports(); showToast('تم تسجيل المصروف','ic-coins');
}
function deleteExpense(id){
  if(!confirm('متأكدة من حذف المصروف؟')) return;
  state.expenses=state.expenses.filter(e=>e.id!==id); saveState(); renderExpenses(); renderDashboard(); renderReports();
}

function recordPurchase(){
  const itemType = document.querySelector('input[name="pur-type"]:checked').value;
  const itemId = document.getElementById('pur-item').value;
  const supplierId = document.getElementById('pur-supplier').value || null;
  const qty = parseFloat(document.getElementById('pur-qty').value);
  const unitCost = parseFloat(document.getElementById('pur-cost').value);

  if(!itemId || !qty || qty<=0 || isNaN(unitCost) || unitCost<0){ alert('استكملي بيانات الشراء (الكمية والتكلفة) صح.'); return; }

  let itemName;
  if(itemType==='raw'){
    const mat = state.rawMaterials[itemId];
    const oldQty = Number(mat.quantity||0), oldCost = Number(mat.unitCost||0);
    const newQty = oldQty + qty;
    mat.unitCost = newQty ? ((oldQty*oldCost) + (qty*unitCost)) / newQty : unitCost;
    mat.quantity = newQty; itemName = mat.name;
  } else {
    const p = state.products[itemId];
    const oldQty = Number(p.stock.quantity||0), oldCost = Number(p.cost||0);
    const newQty = oldQty + qty;
    p.cost = newQty ? ((oldQty*oldCost) + (qty*unitCost)) / newQty : unitCost;
    p.stock.quantity = newQty; itemName = p.name;
  }

  const supplier = supplierId ? state.suppliers.find(s=>s.id===supplierId) : null;
  const totalCost = qty*unitCost;
  const id = (state.purchases[state.purchases.length-1]?.id||0)+1;
  state.purchases.push({ id, ts:Date.now(), supplierId: supplier?supplier.id:null, supplierName: supplier?supplier.name:'بدون مورد محدد', itemType, itemId, itemName, quantity:qty, unitCost, totalCost });
  audit('purchase.recorded', `${itemName} · ${qty} · ${totalCost}`);
  saveState();

  document.getElementById('pur-qty').value=''; document.getElementById('pur-cost').value='';
  renderPurchasesPage(); renderInventory(); renderPos(); renderAdmin(); renderDashboard();
  showToast('تم تسجيل عملية الشراء', 'ic-truck');
}

/* =========================================================
   DASHBOARD
   ========================================================= */
function renderDashboard(){
  setHeroDate();
  const now=new Date(), todayStart=new Date(now.getFullYear(),now.getMonth(),now.getDate()).getTime();
  let todayOrders=state.salesLog.filter(o=>o.ts>=todayStart && (!o.branch || o.branch===currentBranch));
  if(currentUser?.role==='cashier') todayOrders=todayOrders.filter(o=>!o.userId || o.userId===currentUser.id);
  const todayExpenses=state.expenses.filter(e=>e.ts>=todayStart).reduce((s,e)=>s+Number(e.amount||0),0);
  const revenue=todayOrders.reduce((s,o)=>s+o.total,0);
  const cogs=todayOrders.reduce((s,o)=>s+o.items.reduce((x,it)=>x+(it.cost||0)*it.qty,0),0);
  const grossProfit=revenue-cogs, profit=grossProfit-todayExpenses, avgTicket=todayOrders.length?revenue/todayOrders.length:0, inv=inventoryValue();
  document.getElementById('stat-revenue').textContent=fmt(revenue); document.getElementById('stat-gross-profit').textContent=fmt(grossProfit); document.getElementById('stat-expenses').textContent=fmt(todayExpenses);
  const profitEl=document.getElementById('stat-profit'); profitEl.textContent=fmt(profit); profitEl.className='value '+(profit>=0?'profit-pos':'profit-neg');
  document.getElementById('stat-orders').textContent=num(todayOrders.length); document.getElementById('stat-avg').textContent=fmt(avgTicket); document.getElementById('stat-inventory-value').textContent=fmt(inv.total);
  const counts={};todayOrders.forEach(o=>o.items.forEach(it=>{const nm=currentLang==='ar'?it.name:(it.nameEn||it.name);counts[nm]=(counts[nm]||0)+it.qty;}));const entries=Object.entries(counts).sort((a,b)=>b[1]-a[1]);
  document.getElementById('stat-top').textContent=entries.length?`${txt('الأكثر مبيعًا','Top seller')}: ${entries[0][0]} · ${num(entries[0][1])}`:`${txt('الأكثر مبيعًا','Top seller')}: —`;
  const lowRaw=Object.entries(state.rawMaterials).filter(([,m])=>m.quantity<=m.min), lowRetail=Object.values(state.products).filter(p=>p.kind==='retail'&&p.stock.quantity<=p.stock.min), lowCount=lowRaw.length+lowRetail.length;document.getElementById('stat-low').textContent=num(lowCount);
  const body=document.getElementById('recent-orders-body'),recent=[...todayOrders].reverse().slice(0,8);
  if(!recent.length){body.innerHTML=`<tr><td colspan="3"><div class="empty-state"><svg><use href="#ic-cup"/></svg>${txt('لسه مفيش عمليات بيع النهاردة.','No sales yet today.')}</div></td></tr>`;}else{
    body.innerHTML=recent.map(o=>{const time=new Date(o.ts).toLocaleTimeString(loc(),{hour:'2-digit',minute:'2-digit'});const lines=o.items.map(it=>`<div class="order-line"><span class="order-line-name">${currentLang==='ar'?it.name:(it.nameEn||it.name)}</span><span class="order-calc"><span>${num(it.qty)}</span><span>×</span><span>${fmt(it.price)}</span><span>=</span><strong>${fmt(it.total)}</strong></span></div>`).join('');return `<tr><td style="vertical-align:top;direction:ltr">${time}</td><td><div class="order-lines">${lines}</div><div style="font-size:9.5px;color:var(--ink-soft);margin-top:5px">${branchName(o.branch||currentBranch)} · ${o.userNameEn||o.userName||''}</div></td><td class="order-total-cell"><b class="money">${fmt(o.total)}</b></td></tr>`;}).join('');
  }
  const breakEl=document.getElementById('inventory-value-breakdown');if(breakEl){breakEl.innerHTML=`<div class="insight-item"><div><b>${txt('مواد خام','Raw materials')}</b><small>Σ ${txt('الكمية × تكلفة الوحدة','Qty × unit cost')}</small></div><span class="insight-value">${fmt(inv.raw)}</span></div><div class="insight-item"><div><b>${txt('بن معبأ جاهز','Packaged coffee')}</b><small>${txt('العبوات الحالية × تكلفة العبوة','Current packs × pack cost')}</small></div><span class="insight-value">${fmt(inv.retail)}</span></div><div class="insight-item"><div><b>${txt('إجمالي قيمة المخزون','Total inventory value')}</b><small>${num(Object.keys(state.rawMaterials).length)} ${txt('مواد خام','raw materials')} + ${num(Object.values(state.products).filter(p=>p.kind==='retail').length)} ${txt('أصناف معبأة','packaged SKUs')}</small></div><span class="insight-value">${fmt(inv.total)}</span></div>${lowCount?`<div class="insight-item"><div><b style="color:var(--rust)">${txt('محتاج إعادة توريد','Restock needed')}</b><small>${[...lowRaw.map(([,m])=>objName(m)),...lowRetail.map(p=>objName(p))].slice(0,3).join(currentLang==='ar'?'، ':', ')}${lowCount>3?'…':''}</small></div><span class="pill warn">${num(lowCount)} ${txt('أصناف','items')}</span></div>`:`<div class="insight-item"><div><b style="color:var(--leaf)">${txt('المخزون مطمئن','Stock healthy')}</b><small>${txt('لا توجد أصناف تحت الحد الأدنى','No items below minimum')}</small></div><span class="pill ok">${txt('تمام','Good')}</span></div>`}`;}
  applyPermissions();
}

/* =========================================================
   ADMIN — categories
   ========================================================= */
function addCategory(){
  const nameInput = document.getElementById('new-cat-name');
  const iconSelect = document.getElementById('new-cat-icon');
  const name = nameInput.value.trim();
  if(!name) return;
  const id = 'cat_' + Date.now();
  state.categories.push({ id, name, icon: iconSelect.value });
  saveState();
  nameInput.value = '';
  renderAdmin(); renderPos();
  showToast('تمت إضافة الفئة', 'ic-check');
}

function deleteCategory(id){
  const count = Object.values(state.products).filter(p=>p.categoryId===id).length;
  if(count>0){ alert(`الفئة دي فيها ${count} منتج — لازم تنقلي المنتجات لفئة تانية أو تمسحيها الأول.`); return; }
  if(!confirm('متأكدة إنك عايزة تمسحي الفئة دي؟')) return;
  state.categories = state.categories.filter(c=>c.id!==id);
  saveState();
  renderAdmin();
}

function renderCategoriesList(){
  const wrap = document.getElementById('categories-list');
  wrap.innerHTML = state.categories.map(cat=>{
    const count = Object.values(state.products).filter(p=>p.categoryId===cat.id).length;
    return `<div class="cat-row">
      <span class="cat-chip"><svg width="13" height="13"><use href="#${cat.icon}"/></svg> ${objName(cat)} <span style="color:var(--ink-soft)">(${count} منتج)</span></span>
      <button class="btn btn-danger btn-icon" onclick="deleteCategory('${cat.id}')"><svg width="13" height="13"><use href="#ic-trash"/></svg></button>
    </div>`;
  }).join('');
}

/* =========================================================
   ADMIN — products
   ========================================================= */
function renderAdminProductsTable(){
  const body = document.getElementById('admin-products-body');
  const query = (document.getElementById('admin-product-search')?.value || '').trim().toLowerCase();
  const products = Object.values(state.products).filter(p => (selectedAdminCategory==='all' || p.categoryId===selectedAdminCategory) && (!query || p.name.toLowerCase().includes(query)));
  body.innerHTML = products.map(p=>{
    const cat = categoryOf(p.categoryId);
    const kindLabel = p.kind==='prepared' ? 'يُحضّر' : 'جاهز';
    const statusLabel = p.active ? `<span class="pill ok">مفعّل</span>` : `<span class="pill muted">متوقف</span>`;
    const cost = computeProductCost(p);
    const margin = p.price ? Math.round((p.price-cost)/p.price*100) : 0;
    return `<tr>
      <td>${objName(p)}</td>
      <td>${cat ? objName(cat) : '—'}</td>
      <td style="font-size:11.5px;color:var(--ink-soft)">${kindLabel}</td>
      <td>${fmt(p.price)}</td>
      <td>${fmt(cost)}</td>
      <td><span class="qty-number">${num(margin)}%</span></td>
      <td>${statusLabel}</td>
      <td><div class="btn-row">
        <button class="btn btn-ghost btn-icon" onclick="openProductForm('${p.id}')"><svg width="13" height="13"><use href="#ic-edit"/></svg></button>
        <button class="btn btn-danger btn-icon" onclick="deleteProduct('${p.id}')"><svg width="13" height="13"><use href="#ic-trash"/></svg></button>
      </div></td>
    </tr>`;
  }).join('');
}

function selectAdminCategory(categoryId){ selectedAdminCategory=categoryId; renderAdmin(); }

function renderAdminCategoryTabs(){
  const wrap=document.getElementById('admin-category-tabs');
  if(!wrap) return;
  const tabs=[{id:'all',name:'كل المنتجات',count:Object.values(state.products).length,icon:'ic-box'},...state.categories.map(c=>({id:c.id,name:c.name,nameEn:c.nameEn,count:Object.values(state.products).filter(p=>p.categoryId===c.id).length,icon:c.icon}))];
  wrap.innerHTML=tabs.map(t=>`<button class="period-tab ${selectedAdminCategory===t.id?'active':''}" onclick="selectAdminCategory('${t.id}')"><svg style="display:inline-block;width:13px;height:13px;vertical-align:middle"><use href="#${t.icon}"/></svg> ${currentLang==='ar'?(t.name||t.nameEn):(t.nameEn||t.name)} <span style="opacity:.7">(${t.count})</span></button>`).join('');
}

function renderAdmin(){ renderCategoriesList(); renderAdminCategoryTabs(); renderAdminProductsTable(); }

function deleteProduct(id){
  const p = state.products[id];
  if(!confirm(`متأكدة إنك عايزة تمسحي "${p.name}"؟ سجل المبيعات القديم مش هيتأثر.`)) return;
  delete state.products[id];
  saveState();
  renderAdmin(); renderPos(); renderInventory();
  showToast('تم حذف المنتج', 'ic-check');
}

function closeModal(){ document.getElementById('modal-overlay').classList.remove('show'); }

function openProductForm(productId){
  const editing = !!productId;
  const p = editing ? state.products[productId] : null;
  const catOptions = state.categories.map(c=>`<option value="${c.id}" ${p&&p.categoryId===c.id?'selected':''}>${objName(c)}</option>`).join('');
  const kind = p ? p.kind : 'prepared';

  const recipeRows = Object.entries(state.rawMaterials).map(([key,m])=>{
    const val = (p && p.kind==='prepared' && p.recipe[key]) ? p.recipe[key] : '';
    return `<div class="recipe-grid">
      <span>${objName(m)} <span style="color:var(--ink-soft);font-size:11px">(${unitName(m)})</span></span>
      <input type="number" min="0" step="0.1" data-mat="${key}" value="${val}" placeholder="0" oninput="previewPreparedCost()">
    </div>`;
  }).join('');

  document.getElementById('modal-content').innerHTML = `
    <h3>${editing ? 'تعديل منتج' : 'إضافة منتج جديد'}</h3>
    <div class="field"><label>اسم المنتج</label><input type="text" id="pf-name" value="${p?p.name:''}"></div>
    <div class="field"><label>الفئة</label><select id="pf-category">${catOptions}</select></div>
    <div class="field"><label>السعر (ج.م)</label><input type="number" min="0" id="pf-price" value="${p?p.price:''}"></div>
    <div class="field">
      <label>نوع المنتج</label>
      <div class="radio-group">
        <label class="radio-opt ${kind==='prepared'?'selected':''}" id="opt-prepared"><input type="radio" name="pf-kind" value="prepared" ${kind==='prepared'?'checked':''} onchange="toggleKindFields()"> يُحضّر من مواد خام</label>
        <label class="radio-opt ${kind==='retail'?'selected':''}" id="opt-retail"><input type="radio" name="pf-kind" value="retail" ${kind==='retail'?'checked':''} onchange="toggleKindFields()" ${editing?'disabled':''}> يُباع جاهز من مخزون معبأ</label>
      </div>
      ${editing && p.kind==='retail' ? '<div style="font-size:11px;color:var(--ink-soft);margin-top:6px">الكمية بتتحكمي فيها من صفحة المشتريات أو المخزون.</div>' : ''}
    </div>
    <div id="pf-recipe-section" style="display:${kind==='prepared'?'block':'none'}">
      <label style="display:block;font-size:12px;color:var(--ink-soft);margin-bottom:6px">الكمية المستهلكة من كل مادة خام (صفر = مش مستخدمة)</label>
      ${recipeRows}
      <div class="cost-preview" id="pf-cost-preview">التكلفة التقديرية: 0 ج.م</div>
    </div>
    <div id="pf-stock-section" style="display:${kind==='retail'?'block':'none'}">
      <div class="field"><label>تكلفة الشراء لكل عبوة (ج.م)</label><input type="number" min="0" id="pf-cost" value="${p&&p.kind==='retail'?p.cost:''}"></div>
      ${editing ? '' : `
      <div class="field"><label>الكمية الابتدائية في المخزون</label><input type="number" min="0" id="pf-stock-qty" value="0"></div>
      <div class="field"><label>الحد الأدنى للتنبيه</label><input type="number" min="0" id="pf-stock-min" value="3"></div>`}
    </div>
    <div class="modal-actions">
      <button class="btn btn-ghost" onclick="closeModal()">إلغاء</button>
      <button class="btn btn-amber" onclick="saveProductForm(${editing?`'${productId}'`:'null'})"><svg width="14" height="14"><use href="#ic-check"/></svg> حفظ</button>
    </div>`;
  document.getElementById('modal-overlay').classList.add('show');
  if(kind==='prepared') previewPreparedCost();
}

function toggleKindFields(){
  const kind = document.querySelector('input[name="pf-kind"]:checked').value;
  document.getElementById('pf-recipe-section').style.display = kind==='prepared' ? 'block' : 'none';
  document.getElementById('pf-stock-section').style.display = kind==='retail' ? 'block' : 'none';
  document.getElementById('opt-prepared').classList.toggle('selected', kind==='prepared');
  document.getElementById('opt-retail').classList.toggle('selected', kind==='retail');
  if(kind==='prepared') previewPreparedCost();
}

function previewPreparedCost(){
  let cost = 0;
  document.querySelectorAll('#pf-recipe-section input[data-mat]').forEach(inp=>{
    const val = parseFloat(inp.value)||0;
    const mat = state.rawMaterials[inp.dataset.mat];
    if(mat) cost += val*(mat.unitCost||0);
  });
  const el = document.getElementById('pf-cost-preview');
  if(el) el.textContent = 'التكلفة التقديرية: ' + fmt(cost);
}

function saveProductForm(productId){
  const name = document.getElementById('pf-name').value.trim();
  const categoryId = document.getElementById('pf-category').value;
  const price = parseFloat(document.getElementById('pf-price').value);
  const kind = document.querySelector('input[name="pf-kind"]:checked').value;
  if(!name || !price || price<=0){ alert('اكتبي اسم المنتج وسعر صحيح.'); return; }

  const editing = !!productId;
  const id = editing ? productId : ('p_' + Date.now());
  const product = editing ? { ...state.products[id], id, name, nameEn:state.products[id].nameEn||name, categoryId, kind, price } : { id, name, nameEn:name, categoryId, kind, price, active: true };

  if(kind==='prepared'){
    const recipe = {};
    document.querySelectorAll('#pf-recipe-section input[data-mat]').forEach(inp=>{
      const val = parseFloat(inp.value);
      if(val>0) recipe[inp.dataset.mat] = val;
    });
    if(Object.keys(recipe).length===0){ alert('المنتج المُحضّر لازم يكون له وصفة من المواد الخام.'); return; }
    product.recipe = recipe;
  } else {
    const cost = parseFloat(document.getElementById('pf-cost').value)||0;
    product.cost = cost;
    if(editing){ product.stock = state.products[id].stock; }
    else {
      const qty = parseFloat(document.getElementById('pf-stock-qty').value) || 0;
      const min = parseFloat(document.getElementById('pf-stock-min').value) || 0;
      product.stock = { quantity: qty, min };
    }
  }

  state.products[id] = product;
  saveState();
  closeModal();
  renderAdmin(); renderPos(); renderInventory(); renderDashboard();
  showToast(editing ? 'تم تعديل المنتج' : 'تمت إضافة المنتج', 'ic-check');
}

/* =========================================================
   REPORTS
   ========================================================= */
function setReportPeriod(period){
  currentReportPeriod = period;
  document.querySelectorAll('.period-tab').forEach(t=>t.classList.toggle('active', t.dataset.period===period));
  renderReports();
}

function getPeriodStart(period){
  const now = new Date();
  const todayStart = new Date(now.getFullYear(), now.getMonth(), now.getDate()).getTime();
  if(period==='day') return todayStart;
  if(period==='week') return todayStart - 6*86400000;
  return todayStart - 29*86400000;
}

function renderReports(){
  const start = getPeriodStart(currentReportPeriod);
  let orders=state.salesLog.filter(o=>o.ts>=start && (!o.branch||o.branch===currentBranch)); if(currentUser?.role==='cashier') orders=orders.filter(o=>!o.userId||o.userId===currentUser.id);

  const revenue = orders.reduce((s,o)=>s+o.total,0);
  const cogs = orders.reduce((s,o)=>s+o.items.reduce((x,it)=>x+(it.cost||0)*it.qty,0),0);
  const grossProfit = revenue - cogs;
  const periodExpenses = state.expenses.filter(e=>e.ts>=start).reduce((s,e)=>s+Number(e.amount||0),0);
  const netProfit = grossProfit - periodExpenses;
  const margin = revenue ? (netProfit/revenue*100) : 0;
  const count = orders.length;
  const avg = count ? revenue/count : 0;

  const productTotals = {};
  orders.forEach(o=>o.items.forEach(it=>{
    const nm=currentLang==='ar'?it.name:(it.nameEn||it.name); if(!productTotals[nm]) productTotals[nm]={qty:0,total:0}; productTotals[nm].qty+=it.qty; productTotals[nm].total+=it.total;
  }));
  const topList = Object.entries(productTotals).sort((a,b)=>b[1].total-a[1].total);

  document.getElementById('rep-revenue').textContent = fmt(revenue);
  document.getElementById('rep-cogs').textContent = fmt(cogs);
  document.getElementById('rep-gross-profit').textContent = fmt(grossProfit);
  document.getElementById('rep-expenses').textContent = fmt(periodExpenses);
  document.getElementById('rep-profit').textContent = fmt(netProfit);
  document.getElementById('rep-margin').textContent = num(Math.round(margin)) + '%';
  document.getElementById('rep-orders').textContent = num(count);
  document.getElementById('rep-avg').textContent = fmt(avg);
  document.getElementById('rep-top').textContent = topList.length ? topList[0][0] : '—';

  const topBody = document.getElementById('rep-top-products-body');
  topBody.innerHTML = topList.slice(0,5).map(([name,d])=>`<tr><td>${name}</td><td><span class="qty-number">${num(d.qty)}</span></td><td>${fmt(d.total)}</td></tr>`).join('')
    || `<tr><td colspan="3" style="color:var(--ink-soft)">لا يوجد بيانات في الفترة دي.</td></tr>`;

  const chartTitle = document.getElementById('rep-chart-title');
  const chartBody = document.getElementById('rep-chart-body');

  if(currentReportPeriod==='day'){
    chartTitle.innerHTML = `<svg><use href="#ic-chart"/></svg> المبيعات حسب الفئة (النهاردة)`;
    const totals = {};
    orders.forEach(o=>o.items.forEach(it=>{ const cId = it.categoryId || 'other'; totals[cId] = (totals[cId]||0) + it.total; }));
    const rows = Object.entries(totals).map(([cId,total])=>({ name: objName(categoryOf(cId)) || txt('غير مصنّف','Uncategorized'), total })).sort((a,b)=>b.total-a.total);
    const max = Math.max(1, ...rows.map(r=>r.total));
    chartBody.innerHTML = rows.length ? rows.map(r=>`
      <div class="cat-bar-row"><div class="cat-bar-head"><span>${r.name}</span><span>${fmt(r.total)}</span></div>
      <div class="cat-bar-track"><div class="cat-bar-fill" style="width:${Math.round(r.total/max*100)}%"></div></div></div>
    `).join('') : `<div style="color:var(--ink-soft);font-size:13px">لسه مفيش بيع النهاردة.</div>`;
  } else {
    const days = currentReportPeriod==='week' ? 7 : 30;
    chartTitle.innerHTML = `<svg><use href="#ic-chart"/></svg> المبيعات اليومية (آخر ${days} يوم)`;
    const now = new Date();
    const todayStart = new Date(now.getFullYear(), now.getMonth(), now.getDate()).getTime();
    const buckets = [];
    for(let i=days-1;i>=0;i--){
      const dayStart = todayStart - i*86400000;
      const dayEnd = dayStart + 86400000;
      const dayTotal = state.salesLog.filter(o=>o.ts>=dayStart && o.ts<dayEnd).reduce((s,o)=>s+o.total,0);
      buckets.push({ label: new Date(dayStart).toLocaleDateString(loc(),{day:'2-digit',month:'2-digit'}), total: dayTotal });
    }
    const max = Math.max(1, ...buckets.map(b=>b.total));
    chartBody.innerHTML = `<div class="bars-wrap">${buckets.map(b=>`
      <div class="bar-col" title="${fmt(b.total)}"><div class="bar" style="height:${Math.max(2,Math.round(b.total/max*100))}%"></div>${days<=7?`<div class="bar-label">${b.label}</div>`:''}</div>
    `).join('')}</div>`;
  }
}

function exportCSV(period){
  const start = getPeriodStart(period);
  let orders=state.salesLog.filter(o=>o.ts>=start && (!o.branch||o.branch===currentBranch)); if(currentUser?.role==='cashier') orders=orders.filter(o=>!o.userId||o.userId===currentUser.id);
  let csv='Order ID,Date & Time,Branch,Cashier,Order Type,Payment,Item,Qty,Price,Cost,Total\n';
  orders.forEach(o=>{
    const dateStr=new Date(o.ts).toLocaleString('en-GB');
    o.items.forEach(it=>{ csv += `${o.id},${dateStr},${branchName(o.branch||'')},${o.userNameEn||o.userName||''},${o.orderType||''},${o.paymentMethod||''},${it.nameEn||it.name},${it.qty},${it.price},${it.cost||0},${it.total}\n`; });
  });
  const blob = new Blob(["\uFEFF"+csv], {type:'text/csv;charset=utf-8;'});
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url; a.download = `تقرير_المبيعات_${period}.csv`;
  document.body.appendChild(a); a.click(); document.body.removeChild(a);
  URL.revokeObjectURL(url);
}



/* =========================================================
   V9 ERP MODULES
   ========================================================= */
function audit(action,detail=''){ state.auditLog.unshift({id:'aud_'+Date.now(),ts:Date.now(),action,detail,user:currentUser?.username||'system',branch:currentBranch}); state.auditLog=state.auditLog.slice(0,200); saveState(); }
function addCustomer(){const name=document.getElementById('cust-name').value.trim();if(!name){alert('اكتب اسم العميل.');return;}state.customers.push({id:'c_'+Date.now(),name,phone:document.getElementById('cust-phone').value.trim(),email:document.getElementById('cust-email').value.trim(),notes:document.getElementById('cust-notes').value.trim()});audit('customer.created',name);['cust-name','cust-phone','cust-email','cust-notes'].forEach(x=>document.getElementById(x).value='');renderCustomers();}
function deleteCustomer(id){const c=state.customers.find(x=>x.id===id);if(!c)return;if(!confirm('حذف العميل؟'))return;state.customers=state.customers.filter(x=>x.id!==id);audit('customer.deleted',c.name);renderCustomers();}
function renderCustomers(){const b=document.getElementById('customers-body');if(!b)return;b.innerHTML=state.customers.map(c=>`<tr><td>${c.name}</td><td>${c.phone||'—'}</td><td>${c.email||'—'}</td><td>${c.notes||'—'}</td><td><button class="btn btn-danger btn-icon" onclick="deleteCustomer('${c.id}')">×</button></td></tr>`).join('')||'<tr><td colspan="5" class="empty-state">لا يوجد عملاء مسجلون.</td></tr>';}
function populateStockOps(){const opts=Object.entries(state.rawMaterials).map(([id,m])=>`<option value="${id}">${objName(m)}</option>`).join('');['adj-item','transfer-item'].forEach(id=>{const e=document.getElementById(id);if(e)e.innerHTML=opts});const branches=state.branches.map(b=>`<option value="${b.id}">${objName(b)}</option>`).join('');['transfer-from','transfer-to'].forEach(id=>{const e=document.getElementById(id);if(e)e.innerHTML=branches});renderStockMovements();}
function recordAdjustment(){const id=document.getElementById('adj-item').value,q=parseFloat(document.getElementById('adj-qty').value),reason=document.getElementById('adj-reason').value.trim();if(!id||!q){alert('أدخل كمية تسوية صحيحة.');return;}const m=state.rawMaterials[id];if(m.quantity+q<0){alert('التسوية ستجعل المخزون سالبًا.');return;}m.quantity+=q;state.stockMovements.unshift({id:'sm_'+Date.now(),ts:Date.now(),type:'adjustment',itemId:id,itemName:m.name,qty:q,reason:reason||'تسوية مخزون',user:currentUser?.username||'',branch:currentBranch});audit('stock.adjustment',`${m.name}: ${q}`);document.getElementById('adj-qty').value='';document.getElementById('adj-reason').value='';renderStockMovements();renderInventory();renderDashboard();}
function recordTransfer(){const itemId=document.getElementById('transfer-item').value,from=document.getElementById('transfer-from').value,to=document.getElementById('transfer-to').value,qty=parseFloat(document.getElementById('transfer-qty').value);if(from===to){alert('اختار فرعين مختلفين.');return;}if(!qty||qty<=0){alert('أدخل كمية صحيحة.');return;}const m=state.rawMaterials[itemId];state.transfers.unshift({id:'tr_'+Date.now(),ts:Date.now(),itemId,itemName:m.name,from,to,qty,user:currentUser?.username||''});state.stockMovements.unshift({id:'sm_'+Date.now(),ts:Date.now(),type:'transfer',itemId,itemName:m.name,qty,reason:`${branchName(from)} → ${branchName(to)}`,user:currentUser?.username||'',branch:from});audit('stock.transfer',`${m.name}: ${qty} ${branchName(from)} -> ${branchName(to)}`);document.getElementById('transfer-qty').value='';renderStockMovements();}
function renderStockMovements(){const b=document.getElementById('stock-movements-body');if(!b)return;b.innerHTML=state.stockMovements.slice(0,50).map(x=>`<tr><td>${new Date(x.ts).toLocaleString(loc())}</td><td>${x.type==='transfer'?'تحويل':'تسوية'}</td><td>${x.itemName}</td><td>${num(x.qty,2)}</td><td>${x.reason||'—'}</td><td>${x.user||'—'}</td></tr>`).join('')||'<tr><td colspan="6" class="empty-state">لا توجد حركات مخزون مستقلة مسجلة.</td></tr>';}
function recordCashEntry(){const type=document.getElementById('cash-type').value,amount=parseFloat(document.getElementById('cash-amount').value),category=document.getElementById('cash-category').value.trim(),note=document.getElementById('cash-note').value.trim();if(!amount||amount<=0){alert('أدخل قيمة صحيحة.');return;}state.cashEntries.unshift({id:'ce_'+Date.now(),ts:Date.now(),type,amount,category:category||'عام',note,user:currentUser?.username||'',branch:currentBranch});audit('cash.entry',`${type} ${amount}`);document.getElementById('cash-amount').value='';document.getElementById('cash-category').value='';document.getElementById('cash-note').value='';renderFinance();}
function renderFinance(){const b=document.getElementById('cash-body');if(!b)return;const ins=state.cashEntries.filter(x=>x.type==='in').reduce((s,x)=>s+x.amount,0),outs=state.cashEntries.filter(x=>x.type==='out').reduce((s,x)=>s+x.amount,0);document.getElementById('cash-in').textContent=fmt(ins);document.getElementById('cash-out').textContent=fmt(outs);document.getElementById('cash-balance').textContent=fmt(ins-outs);b.innerHTML=state.cashEntries.map(x=>`<tr><td>${new Date(x.ts).toLocaleString(loc())}</td><td><span class="pill ${x.type==='in'?'ok':'warn'}">${x.type==='in'?'قبض':'صرف'}</span></td><td>${x.category}</td><td>${x.note||'—'}</td><td>${fmt(x.amount)}</td></tr>`).join('')||'<tr><td colspan="5" class="empty-state">لا توجد قيود خزينة مسجلة.</td></tr>';}
function openShift(){if(state.shifts.some(x=>!x.closedAt&&x.branch===currentBranch)){alert('يوجد وردية مفتوحة بالفعل لهذا الفرع.');return;}state.shifts.unshift({id:'sh_'+Date.now(),branch:currentBranch,userId:currentUser?.id,user:currentUser?.name||currentUser?.username,openedAt:Date.now(),closedAt:null});audit('shift.opened',branchName(currentBranch));renderOperations();}
function closeShift(){const sh=state.shifts.find(x=>!x.closedAt&&x.branch===currentBranch);if(!sh){alert('لا توجد وردية مفتوحة لهذا الفرع.');return;}sh.closedAt=Date.now();audit('shift.closed',branchName(currentBranch));renderOperations();}
function renderOperations(){const cur=document.getElementById('current-shift'),body=document.getElementById('shifts-body');if(!cur||!body)return;const sh=state.shifts.find(x=>!x.closedAt&&x.branch===currentBranch);cur.innerHTML=sh?`<b>${branchName(sh.branch)}</b> · ${sh.user||'—'} · بدأ ${new Date(sh.openedAt).toLocaleString(loc())}`:'لا توجد وردية مفتوحة.';body.innerHTML=state.shifts.map(x=>`<tr><td>${branchName(x.branch)}</td><td>${x.user||'—'}</td><td>${new Date(x.openedAt).toLocaleString(loc())}</td><td>${x.closedAt?new Date(x.closedAt).toLocaleString(loc()):'—'}</td><td><span class="pill ${x.closedAt?'muted':'ok'}">${x.closedAt?'مغلقة':'مفتوحة'}</span></td></tr>`).join('')||'<tr><td colspan="5" class="empty-state">لا توجد ورديات مسجلة.</td></tr>';}
function renderAudit(){const e=document.getElementById('audit-body');if(!e)return;e.innerHTML=state.auditLog.slice(0,50).map(a=>`<div class="audit-line"><b>${a.action}</b> — ${a.detail||'—'}<small>${new Date(a.ts).toLocaleString(loc())} · @${a.user} · ${branchName(a.branch)}</small></div>`).join('')||'<div class="empty-state">لا توجد أحداث مسجلة بعد.</div>';}
function renderERPModules(){renderTables();renderCustomers();populateStockOps();renderFinance();renderOperations();renderAudit();}

function applyTheme(theme){
  const value=theme==='dark'?'dark':'light';
  document.documentElement.setAttribute('data-theme',value);
  localStorage.setItem('coffeeSpaceTheme',value);
  const icon=value==='dark'?'☀':'☾';
  const a=document.getElementById('theme-btn'), b=document.getElementById('login-theme-btn');
  if(a)a.textContent=icon; if(b)b.textContent=icon;
}
function toggleTheme(){ applyTheme(document.documentElement.getAttribute('data-theme')==='dark'?'light':'dark'); }
applyTheme(localStorage.getItem('coffeeSpaceTheme')||'light');

/* =========================================================
   INIT
   ========================================================= */
renderPos(); renderCart(); renderInventory(); populateWasteItems(); renderDashboard(); renderAdmin(); renderReports(); renderPurchasesPage(); restoreSession(); updateSessionUI(); applyLanguage();
renderExpenses(); renderERPModules();

const i18nObserver=new MutationObserver(muts=>{if(currentLang!=='en')return;for(const m of muts){m.addedNodes.forEach(n=>{if(n.nodeType===1)applyLanguage(n);});}});i18nObserver.observe(document.body,{childList:true,subtree:true});
